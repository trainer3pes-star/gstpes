
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.2
    </div>
    <strong>Copyright &copy; <?php echo date('Y');?> <a href="<?php echo base_url();?>" target="_blank" ><?php echo SITE_NAME;?></a>.</strong> <?php echo $this->lang->line('common_all');?> rights
    reserved.
  </footer>

   <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
  <input type="hidden" id="js_error_mandatory_msg" value="<?php echo $this->lang->line('common_error_mandatory_msg');?>"> 
    
   <div class="modal fade" id="modal-sm">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title"><?php echo $this->lang->line('common_hello_label');?> <?php echo ucfirst($login_user_info->name); ?>  </h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <p><?php echo $this->lang->line('common_popup_msg');?></p>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('common_no');?></button>
			   <a href ="Home/change-password" type="button" class="btn btn-danger"><?php echo $this->lang->line('change_password_title');?></a>
              <a href ="Home/logout" type="button" class="btn btn-primary"><?php echo $this->lang->line('common_yes');?></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->
	  
	  
   <div class="modal fade" id="feed_back_model">
        <div class="modal-dialog  ">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title"><?php echo $this->lang->line('common_feedback_label');?> </h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <p><textarea style="width:100%" name="feedback" id="feedback" maxlength="255"></textarea></p>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('common_close_btn');?></button>
              <button type="button" class="btn btn-info"  id='save_feedback'><?php echo $this->lang->line('common_save_close_btn');?></button>
			<input id="review_hidden_id" name="review_hidden_id" value="" type="hidden">
			</div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->
	  
	    
   <div class="modal fade" id="comment_back_model">
        <div class="modal-dialog  ">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Comment</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <p><textarea style="width:100%" name="comment" id="comment" maxlength="255"></textarea></p>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('common_close_btn');?></button>
              <button type="button" class="btn btn-info"  id='save_comment'><?php echo $this->lang->line('common_save_close_btn');?></button>
			<input id="record_id_pending" name="record_id" value="" type="hidden">
			<input id="record_action" name="record_action" value="" type="hidden">
			</div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->
	 
	 
	 <div class="modal fade modal-default " id="master_run_model" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
     	<div class="modal-dialog modal-lg " >
                <div class="modal-content" >
                   <div class="modal-header">
                   
                    <h5 class="modal-title run_time_title" >&nbsp;</h5><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  </div>
                 
                  <div class="modal-body ajax_master_run" >
				   
           
         
                </div> 
              </div>
    </div>
	</div>