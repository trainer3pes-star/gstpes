<div class="row">
	<div class="col-md-12" style="overflow: auto;">
		 <form method="post" action="product/save_product_module_stock" id="ajax_save_st" name="ajax_save_st"><table class="table table-bordered table-striped col-xs-12" >
			<tr>
				<?php foreach($mresults as $mresult){?>
				<td><?php echo $mresult->module_name;?></td>
				<?php } ?>
				<td>Current Stock</td>
				<td>New Add Stock</td>  
				<td>Mark Defect Stock</td>  
				<td>Total Inward</td>  
				<td>Total sell</td>  
				<td>Total Cancelled</td>  
				<td>Total Defect Stock</td>   
			</tr>
			 <?php 
			foreach($variations as $variation){  
				$sub_html="";
				$ex_variation=explode('@',$variation->variation_string);
				foreach($ex_variation as $ex_variation_sub){
					$val_md=explode('=>',$ex_variation_sub);
					$sub_html=$sub_html.'<td>'.$val_md[1].'</td>';
				}
				$checked="";
				if(@$variation->is_active){
					$checked=" checked ";
				}
				echo $rhtml='<tr style="text-align: center;" class="tr_r'.$variation->id.'">'.$sub_html.'<td>'.$variation->current_stock.'</td><td> </td><td> </td><td> </td><td> </td><td> </td><td> </td> </tr>';
			} ?> 
		 </table></form>
	</div>
</div>