 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo $page_title;?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right"> 
			 <li class="breadcrumb-item"><a href="Home"><?php echo $this->lang->line('dashboard_page_title');?></a></li>
              <li class="breadcrumb-item active"><?php echo $page_title;?></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
	 <div class="col-md-12">
<div class="alert alert-danger alert-dismissible"  <?php if(@strlen($this->session->flashdata('errorsmsg'))){?> style="display:block" <?php }else{?> style="display:none" <?php } ?>>
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h5><i class="icon fas fa-ban"></i> <?php echo $this->lang->line('common_error');?> !</h5>
                 <?php echo $this->session->flashdata('errorsmsg') ?> 
                </div>
				<div class="alert alert-success alert-dismissible" <?php if(@strlen($this->session->flashdata('successmsg'))){?> style="display:block" <?php }else{?> style="display:none" <?php } ?>>
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h5><i class="icon fas fa-check"></i><?php echo $this->lang->line('common_success');?> ! </h5>
                  <?php echo $this->session->flashdata('successmsg') ?> 
                </div>
                </div>
<div class="row">
      <!-- Default box -->
     <div class="col-md-2"></div>
	  <div class="col-md-8">
	<?php echo form_open_multipart('admin/User/user-company/'.$uresult->id, array('id' => 'basic_search','class'=>'form-horizontal adminex-form' ,'enctype'=>'multipart/form-data')); ?>
	  
      </div>
    </div>
	<!-- /.card -->
<div class="row">
      <!-- Default box -->
    <div class="col-md-12">
	<div class="card">
        <div class="card-header">
		 

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fas fa-minus"></i></button>
            
          </div>
		 	  	   
<?php if($this->Home_model->check_permission('1','PExport')){?>
<div class="col-sm-2" style="float:right;"> 
				<input data-frm="basic_search" type="button" name="export" id="export_excel" value="<?php echo $this->lang->line('common_export_btn');?>" class="btn btn-default" style="width:100%;float:right" />
			</div>
		  <?php } ?>
        </div>
		<?php if($this->Home_model->check_permission('1','PList')){?>
        <div class="card-body">
           <table id="example_php" class="table table-bordered table-striped col-xs-12" >
								<thead>
									<tr >
										<th>#</th>
										  
										<th> Company Name</th>
										<th> Company Type</th>
										<th> Company Logo</th>
										<th> Status</th>
										<th> Credit Facility</th>
										<th> AF</th>
										<th> View Details</th>
										<th> View Documents</th>
										<th> View Approval History</th>
										<th> Send to Bank for Approval</th>
										<th> Send Reply to Customer </th>
										  
									</tr>
								</thead>
								<tbody>
									<?php $i=1; foreach(@$results as $result){ ?>
									<tr  >
										<td><?php echo ($search['no_of_records']*$search['pagi_number'])+$i++ ; ?></td>
										<td><?php echo $result->company_name;?></td> 
										<td><?php echo $result->comapny_type;?></td>  
										<td>
										 <img src="<?php echo base_url();?>uploads/users/thumb/<?php echo $result->company_logo;?>" width="50px" title="<?php echo $result->company_name;?>">
										</td>  
										<td><?php if($result->status==0){ echo "Pending";}else{ echo "Approved";} ?></td>   
										<td><?php if($result->credit_facility==0){ echo "No";}else{ echo "Yes";} ?></td>   
										<td><?php echo $result->create_from;?></td>   
										 
										  
										<td><a target="_blank" class="btn btn-xs btn-success" href="User/user-detail/<?php echo $result->user_id?>"  title="View User Info "><i class="fas fa-eye "></i></a></td>
										
										<td><a class="btn btn-xs bg-fuchsia  " href="User/user-documents/<?php echo $result->user_id?>/<?php echo $result->id?>"  title="View Documents "><i class="fas fa-file "></i></a></td>
										
										<td><a  target="_blank"  class="btn btn-xs bg-lime" href="User/user-company-history/<?php echo $result->user_id?>/<?php echo $result->id?>"  title="View User Info ">  View History</a></td>
										<td>
										<?php if($result->credit_facility==1){?>
										<a class="btn btn-xs btn-info send_bank_model" href="javascript:void(0);" company_id="<?php echo $result->id?>" user_id="<?php echo $result->user_id?>" data-compnay-name="<?php echo $result->company_name;?>" title="View User Info "> Send To Bank Approval</a>
										<?php } ?>
										</td>
										<td>
										<a class="btn btn-xs btn-warning btn_send_customer_model" href="javascript:void(0);" company_id="<?php echo $result->id?>" user_id="<?php echo $result->user_id?>" data-compnay-name="<?php echo $result->company_name;?>" title=" Send To Customer  "> Send To Customer  </a></td>
										 
									</tr>
									<?php } ?>
								</tbody>
								 
							</table>
							
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
	 
        </div>
        <!-- /.card-footer-->
		<?php }else{ ?> 
		<center><h1 style="color:red">Permission Denied</h1></center>
		<?php }?>
      </div>
	</div>
</div>
    </form> </section>
    <!-- /.content -->
  </div>
  
  
      
   <div class="modal fade" id="send_bank_model">
        <div class="modal-dialog  ">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Send To Bank Approval </h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
			<form method="post"  id="send_bank_approval" name="send_bank_approval" action="User/send_to_bank_approval">
            <div class="modal-body">
			<p>
			<b>Company Name : <span id="com_name"></span></b><br>
			<b>Customer Name : <?php echo $uresult->name;?></b>
			</p>
              <p>
			  Select Bank : <br>
			  <select name="bank_ids[]" id="bank_ids" class="form-control select2" > 
				<?php foreach($bannk_results as $bannk_result){?>
					<option value="<?php echo $bannk_result->id?>"><?php echo $bannk_result->bank_name?></option>
				<?php } ?>
			  </select>
			  </p>
              <p>
			  Comment :<br>
			  <textarea style="width:100%" name="comment" id="comment" maxlength="255"></textarea></p>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('common_close_btn');?></button>
              <button type="button" class="btn btn-info"  id='se_to_banks' data-frm="send_bank_approval"><?php echo $this->lang->line('common_save_close_btn');?></button>
			<input id="send_user_id" name="user_id" value="" type="hidden">
			<input id="send_company_id" name="company_id" value="" type="hidden">
			<input id="com_name" name="com_name" value="" type="hidden">
			<input id="cust_name" name="cust_name" value="<?php echo $uresult->name;?>" type="hidden">
			</div>
			</form>
		  </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->
	
 
      
   <div class="modal fade" id="send_customer_model">
        <div class="modal-dialog  ">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Send To Customer </h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
			<form method="post"  id="send_customer_approval" name="send_customer_approval" action="User/send_customer_approval">
            <div class="modal-body">
			<p>
			<b>Company Name : <span id="com_name1"></span></b><br>
			<b>Customer Name : <?php echo $uresult->name;?></b>
			</p>
              <p>
			  Select Status  : <br>
			  <select name="status" id="status" class="form-control select2" > 
				<option value="0">Pending(Query) </option>
				<option value="1">Approved </option>
				<option value="2">Rejected </option>
				
			  </select>
			  </p>
              <p>
			  Comment :<br>
			  <textarea style="width:100%" name="comment" id="cust_comment" maxlength="255"></textarea></p>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('common_close_btn');?></button>
              <button type="button" class="btn btn-info"  id='se_to_customer' data-frm="send_customer_approval"><?php echo $this->lang->line('common_save_close_btn');?></button>
			<input id="sendc_user_id" name="user_id" value="" type="hidden">
			<input id="sendc_company_id" name="company_id" value="" type="hidden">
			<input id="com_name" name="com_name" value="" type="hidden">
			<input id="cust_name" name="cust_name" value="<?php echo $uresult->name;?>" type="hidden">
			</div>
			</form>
		  </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->
	